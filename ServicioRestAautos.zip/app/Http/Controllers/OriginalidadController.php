<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Originalidad;

class OriginalidadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $originalidad = Originalidad::all();
        return $originalidad;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $originalidad = new Originalidad();
        $originalidad->idOriginalidad = $request->idOriginalidad;
        $originalidad->nombre = $request->nombre;
        $originalidad->siglas = $request->siglas;
        $originalidad->descripcion = $request->descripcion;

        $originalidad->save();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $originalidad = Originalidad::findOrFail($request->id);
        $originalidad->idOriginalidad = $request->idOriginalidad;
        $originalidad->nombre = $request->nombre;
        $originalidad->siglas = $request->siglas;
        $originalidad->descripcion = $request->descripcion;

        $originalidad->save();

        return $originalidad;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $originalidad = Originalidad::destroy($request->idOriginalidad);
        return $originalidad;
    }
}
