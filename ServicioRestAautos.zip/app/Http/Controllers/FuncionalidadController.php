<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Funcionalidad;

class FuncionalidadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $funcionalidad = Funcionalidad::all();
        return $funcionalidad;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $funcionalidad = new Funcionalidad();
        $funcionalidad->idFuncional = $request->idFuncional;
        $funcionalidad->criterio = $request->criterio;
        $funcionalidad->descripcion = $request->descripcion;

        $funcionalidad->save();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $funcionalidad = Funcionalidad::findOrFail($request->id);
        $funcionalidad->idFuncional = $request->idFuncional;
        $funcionalidad->criterio = $request->criterio;
        $funcionalidad->descripcion = $request->descripcion;

        $funcionalidad->save();

        return $funcionalidad;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $funcionalidad = Funcionalidad::destroy($request->idEvFuncional);
        return $funcionalidad;
    }
}
